var searchData=
[
  ['ff_5fchannel_5forder_5fnb_0',['FF_CHANNEL_ORDER_NB',['../group__lavu__audio__channels.html#gga252e1528ae55fbf873266ca4c7e3b69ca22b3e1a45b055b8ecd95b1f4b2d9dbb4',1,'channel_layout.h']]]
];
