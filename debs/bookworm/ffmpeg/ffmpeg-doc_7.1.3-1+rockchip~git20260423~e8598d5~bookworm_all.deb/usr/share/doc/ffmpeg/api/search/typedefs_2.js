var searchData=
[
  ['fftcontext_0',['FFTContext',['../group__lavc__fft.html#gaac01e094370275491c7cbc580de0fe24',1,'avfft.h']]],
  ['fftsample_1',['FFTSample',['../group__lavc__fft.html#gaa306dc16df543b25d9910debc3f76b96',1,'avfft.h']]]
];
