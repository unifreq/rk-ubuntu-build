var searchData=
[
  ['samples_20manipulation_0',['Samples manipulation',['../group__lavu__sampmanip.html',1,'']]],
  ['send_2freceive_20encoding_20and_20decoding_20api_20overview_1',['send/receive encoding and decoding API overview',['../group__lavc__encdec.html',1,'']]],
  ['setting_20and_20modifying_20option_20values_2',['Setting and modifying option values',['../group__opt__write.html',1,'']]],
  ['sha_3',['SHA',['../group__lavu__sha.html',1,'']]],
  ['sha_2d512_4',['SHA-512',['../group__lavu__sha512.html',1,'']]],
  ['spherical_20video_20mapping_5',['Spherical video mapping',['../group__lavu__video__spherical.html',1,'']]],
  ['stereo3d_20types_20and_20functions_6',['Stereo3D types and functions',['../group__lavu__video__stereo3d.html',1,'']]],
  ['string_20manipulation_7',['String Manipulation',['../group__lavu__string.html',1,'']]]
];
