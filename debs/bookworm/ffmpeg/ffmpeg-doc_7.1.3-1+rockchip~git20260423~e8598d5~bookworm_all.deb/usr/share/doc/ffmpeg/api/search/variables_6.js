var searchData=
[
  ['g_0',['g',['../structAVPrimaryCoefficients.html#a83f986cfb96f7f41a2badb1dbfda3296',1,'AVPrimaryCoefficients']]],
  ['get_5fbuffer2_1',['get_buffer2',['../structAVCodecContext.html#aef79333a4c6abf1628c55d75ec82bede',1,'AVCodecContext']]],
  ['get_5fcategory_2',['get_category',['../structAVClass.html#a511382185d3206043d5d37c1007f199c',1,'AVClass']]],
  ['get_5fencode_5fbuffer_3',['get_encode_buffer',['../structAVCodecContext.html#a610bca24031c26f6ac6c6f4ff11a05b4',1,'AVCodecContext']]],
  ['get_5fformat_4',['get_format',['../structAVCodecContext.html#a360a2b8508a67c4234d97f4c13ba1bb5',1,'AVCodecContext']]],
  ['get_5fpixels_5',['get_pixels',['../structAVDCT.html#a28cd1e0bb3528d9451851dd105b4f10d',1,'AVDCT']]],
  ['get_5fpixels_5funaligned_6',['get_pixels_unaligned',['../structAVDCT.html#ac1a3419009d9a20f6239e6edc7c4979e',1,'AVDCT']]],
  ['get_5fproc_5faddr_7',['get_proc_addr',['../structAVVulkanDeviceContext.html#ae474efae27f4861ed96a941965410c6a',1,'AVVulkanDeviceContext']]],
  ['get_5fproc_5faddress_8',['get_proc_address',['../structAVVDPAUDeviceContext.html#a914811a6a5ce27995a8e1fd03254ae18',1,'AVVDPAUDeviceContext']]],
  ['global_5fquality_9',['global_quality',['../structAVCodecContext.html#a209f5ec60cb5f0b0a4962f4c5c5bb541',1,'AVCodecContext']]],
  ['gop_5fsize_10',['gop_size',['../structAVCodecContext.html#a9b6b3f1fcbdcc2ad9f4dbb4370496e38',1,'AVCodecContext']]],
  ['grain_5fscale_5fshift_11',['grain_scale_shift',['../structAVFilmGrainAOMParams.html#a43cb8295c434f35879f08e0717123aa0',1,'AVFilmGrainAOMParams']]],
  ['graph_12',['graph',['../structAVFilterContext.html#a9454cf1790adf4f966d0350c3af72aa3',1,'AVFilterContext::graph()'],['../structAVFilterGraphSegment.html#aad08691994b8cf592c6cdd4a377e60c9',1,'AVFilterGraphSegment::graph()']]],
  ['group_5fid_13',['group_id',['../structAVIODirEntry.html#ab216aad5f996681f498158cc82803fe2',1,'AVIODirEntry']]]
];
