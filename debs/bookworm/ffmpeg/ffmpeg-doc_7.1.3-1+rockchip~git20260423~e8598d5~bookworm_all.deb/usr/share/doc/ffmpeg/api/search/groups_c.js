var searchData=
[
  ['option_20getting_20functions_0',['Option getting functions',['../group__opt__get__funcs.html',1,'']]],
  ['option_20setting_20functions_1',['Option setting functions',['../group__opt__set__funcs.html',1,'']]],
  ['other_2',['Other',['../group__lavu__misc.html',1,'']]]
];
