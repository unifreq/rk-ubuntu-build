var indexSectionsWithContent =
{
  0: "35_abcdefghijklmnopqrstuvwxy",
  1: "abdforsu",
  2: "abcdefhijlmopqrstuvx",
  3: "acdefghilmoprstuw",
  4: "abcdefghiklmnopqrstuvwxy",
  5: "as",
  6: "ads",
  7: "adfs",
  8: "_adfgilmnoprsv",
  9: "35abcdefghilmnoprstuvwx",
  10: "dflt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

