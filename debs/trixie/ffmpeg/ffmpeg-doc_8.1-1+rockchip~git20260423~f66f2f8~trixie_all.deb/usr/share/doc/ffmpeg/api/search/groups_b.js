var searchData=
[
  ['layouts_0',['Audio channel layouts',['../group__channel__mask__c.html',1,'']]],
  ['libavcodec_1',['libavcodec',['../group__libavc.html',1,'']]],
  ['libavdevice_2',['libavdevice',['../group__lavd.html',1,'']]],
  ['libavfilter_3',['libavfilter',['../group__lavfi.html',1,'']]],
  ['libavformat_4',['libavformat',['../group__libavf.html',1,'']]],
  ['libavutil_5',['libavutil',['../group__lavu.html',1,'']]],
  ['library_20version_20macros_6',['Library Version Macros',['../group__version__utils.html',1,'']]],
  ['library_20wrappers_7',['library wrappers',['../group__lavf__codec__wrappers.html',1,'External library wrappers'],['../group__lavc__codec__wrappers.html',1,'External library wrappers']]],
  ['libswresample_8',['libswresample',['../group__lswr.html',1,'']]],
  ['libswscale_9',['libswscale',['../group__libsws.html',1,'']]],
  ['logging_20constants_10',['Logging Constants',['../group__lavu__log__constants.html',1,'']]],
  ['logging_20facility_11',['Logging Facility',['../group__lavu__log.html',1,'']]],
  ['lzo_12',['LZO',['../group__lavu__lzo.html',1,'']]]
];
