var searchData=
[
  ['filteringcontext_0',['FilteringContext',['../structFilteringContext.html',1,'']]]
];
