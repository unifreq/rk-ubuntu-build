# rkllm-runtime 1.3.1

RKLLM Runtime —— Rockchip NPU 平台的大语言模型（LLM）推理运行时。

## 在 RKLLM 软件栈中的位置

RKLLM 软件栈用于将 AI 模型快速部署到 Rockchip 芯片，整体流程：

```
PC 端                         开发板端
┌──────────────────┐          ┌──────────────────┐
│ RKLLM-Toolkit    │          │ RKLLM Runtime    │
│ 模型转换 + 量化   │  ──────> │ C/C++ 推理接口    │  ← 本包
└──────────────────┘  .rkllm  └────────┬─────────┘
                                       │
                              ┌────────▼─────────┐
                              │ RKNPU 内核驱动    │
                              │ （Rockchip 内核） │
                              └────────┬─────────┘
                                       │
                              ┌────────▼─────────┐
                              │   NPU 硬件        │
                              └──────────────────┘
```

- **RKLLM-Toolkit**：PC 端 SDK，负责模型转换与量化
- **RKLLM Runtime**（本包）：开发板端 C/C++ 编程接口，部署 RKLLM 模型并加速 LLM 应用
- **RKNPU 内核驱动**：与 NPU 硬件交互（已开源，位于 Rockchip 内核代码中）

## 支持平台

- RK3588 系列
- RK3576 系列
- RK3562 系列
- RV1126B 系列

> **注意**：**不支持 RK182x 协处理器**。库内硬编码校验：
> `Platform error, must be either RK3588, RK3576, RV1126B or RK3562.`
>
> RK182x 的 LLM 推理请使用 `rknn3-runtime-llm` 包（提供 `rkllm3-server`）。

## 支持模型

Spark-X2.5、LFM2.5-VL-450M、LLAMA、TinyLLAMA、Qwen2/Qwen2.5/Qwen3/Qwen3.5、
Phi2/Phi3、ChatGLM3-6B、Gemma2/Gemma3/Gemma3n/Gemma4、InternLM2、
MiniCPM3/MiniCPM4、TeleChat2、Qwen2-VL/Qwen3-VL、MiniCPM-V-2_6、
DeepSeek-R1-Distill、Janus-Pro-1B、InternVL2-1B/InternVL3-1B、
SmolVLM/SmolLM3、RWKV7、DeepSeekOCR

## 内容

| 文件 | 说明 |
|---|---|
| `/usr/lib/aarch64-linux-gnu/librkllmrt.so` | RKLLM 运行时库（7.3 MB） |
| `/usr/include/rkllm.h` | RKLLM C API 头文件 |

## 使用

```bash
# 编译示例
gcc -o demo demo.c -lrkllmrt -lgomp
```

## 依赖

运行时依赖 `libgomp.so.1`（OpenMP，由 `libgomp1` 包提供），
用于并行推理加速。

> 上游 README 提示：某些平台可能报 `libomp.so` 找不到。
> 此时需从交叉编译工具链中取出该库，放到开发板 lib 目录下，
> 与 `librkllmrt.so` 同级。

## 与其他 runtime 的关系

| 包 | 用途 | 支持平台 | 依赖关系 |
|---|---|---|---|
| `rkllm-runtime` | LLM 推理（本包） | RK3588/RK3576/RK3562/RV1126B | 无 |
| `rknn2-runtime` | RKNN2 模型（本机 NPU） | RK3572/RK3588 等 | 无 |
| `rknn3-runtime` | RKNN3 模型 | RK182x 协处理器 | 无 |
| `rknn3-runtime-llm` | RK182x 上的 LLM 推理 | RK182x 协处理器 | `rknn3-runtime` |

四者**互相独立**（除 `rknn3-runtime-llm` 依赖 `rknn3-runtime`），可共存。
`librkllmrt.so` 不直接依赖 `librknnrt.so` 或 `librknn3_api.so`，
通过 RKNPU 内核驱动直接访问硬件。

## 版本

- 包版本：1.3.1
- 来源：rknn-llm `rkllm-runtime/Linux/librkllm_api`
- 上游 commit：`f7390530443bf84f0394255a449d7cbe81e69d1c`
