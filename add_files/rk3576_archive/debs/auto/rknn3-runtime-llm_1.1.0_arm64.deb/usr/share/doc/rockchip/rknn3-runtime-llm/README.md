# rknn3-runtime-llm 1.1.0

RKLLM3 大语言模型推理服务，用于 Rockchip **RK182x** AI 协处理器。

## 支持的平台

| 型号 | 是否支持 LLM |
|---|---|
| RK1820 | 支持 |
| RK1828 | 支持 |
| RK3572 | **不支持**（本机 NPU 无 LLM 能力） |

> 本包依赖 `rknn3-runtime`（共享 `librknn3_api.so`）。
> 在仅有 RK3572 本机 NPU 的系统上安装本包没有意义。

## 与 rkllm-runtime 的区别

| 包 | 上游 | 目标硬件 | 模型格式 |
|---|---|---|---|
| `rknn3-runtime-llm`（本包） | rknn3-toolkit | RK1820 / RK1828 协处理器 | `.rknn`（RKNN3） |
| `rkllm-runtime` | rknn-llm | RK3588 / RK3576 / RK3562 / RV1126B | `.rkllm` |

两者**互不替代**，面向不同硬件与不同模型格式。

## 内容

| 文件 | 说明 |
|---|---|
| `/usr/bin/rkllm3-server` | LLM HTTP 服务端（OpenAI API 兼容） |
| `/usr/lib/aarch64-linux-gnu/librkllm3-server.so` | 服务端库 |
| `/usr/include/rkllm3-server.h` | 服务端头文件 |
| `/usr/share/doc/rockchip/rknn3-runtime-llm/README_CN.md` | 完整参数说明（上游） |

## 为什么没有 systemd service

`rkllm3-server` 是**应用层工具**，启动时必须携带大量模型相关参数
（`-m` / `--vocab` / `--embed` / `--host` / `--port` / `-c` / `-n` 等），
不同模型与场景参数差异很大，无法用固定 service 表达。

请按需手动启动，例如：

```bash
rkllm3-server -m qwen2.5-3b.rknn \
    --vocab qwen2.5-3b.tokenizer.gguf \
    --embed qwen2.5-3b.embed.bin \
    --host 0.0.0.0 --port 8080 -c 768 --n_predict 512
```

完整参数见 `/usr/share/doc/rockchip/rknn3-runtime-llm/README_CN.md`。

## 版本

- 包版本：1.1.0
- 来源：rknn3-toolkit `rknn3-runtime/rkllm3-server`

