# rknn3-rk182x-firmware-sodimm-net 1.1.0

RK182x AI 协处理器固件镜像（**sodimm-net** 变体）。

## 内容

| 文件 | 说明 |
|---|---|
| `/usr/lib/firmware/rknn3_rk1820.img` | RK182x 固件镜像（RKFW 格式） |

## 变体说明

| 变体 | 封装形态 | 通信接口 |
|---|---|---|
| `m2` | M.2 模组 | PCIe |
| `sodimm` | SODIMM 模组 | PCIe |
| `sodimm-net` | SODIMM 模组 | 以太网（lwIP + mDNS + DHCP） |

> 封装形态（PCB 接口规范）与通信接口是**正交**的两个维度：
> M.2 模组也可能是 USB 接口，SODIMM 也可能是以太网接口。
> 因此本工程按上游提供的三份固件原样分包，不做合并。

## 互斥关系

三个固件包**互斥**（`Conflicts` + `Replaces`），同一系统只能安装一个。
安装本包会自动移除另外两个。

## 固件如何被刷入

| 场景 | 触发方式 |
|---|---|
| PCIe | `rknn3.service` 的 `ExecStartPre=-rknn3_startup` |
| USB MaskROM | udev 规则 `2207:180b` → `rknn3_usb_startup@.service` |

刷写前会先探测 EP 是否已运行（`rknn-smi info -t board` 返回 `Online`），
已运行则跳过，避免重复刷写导致 `0xffa70000` 错误。

## 依赖

`Depends: rknn3-rk182x-hwcontrol (>= 1.1.0)`

固件本身没有可执行代码，必须配合 hwcontrol 包中的上传工具使用。

## 版本

- 包版本：1.1.0
- 来源：上游 v1.1.0 对应变体安装包
