# pcie-rkep-dkms 1.1.0

RK182x PCIe Endpoint 内核驱动（DKMS 源码包）。

## 这是可选包

**大多数情况下不需要安装**。只有当运行中的内核**没有**内置 `pcie-rkep`
驱动时才需要。

检查方法（任一成功即说明驱动已就绪）：

```bash
ls /sys/bus/pci/drivers/pcie-rkep
modinfo pcie-rkep
```

## 内容

| 路径 | 说明 |
|---|---|
| `/usr/src/pcie-rkep-3.3.1/` | DKMS 源码树 |
| `/usr/share/pcie-rkep-dkms/` | DKMS 钩子脚本（postinst/prerm/postrm） |

## 依赖

`Depends: dkms, make, gcc, linux-headers-generic | linux-headers-arm64`

安装时会自动编译并加载模块。若编译失败，包仍会安装成功但打印警告。

## 与 hwcontrol 的关系

`rknn3-rk182x-hwcontrol` 只 **Recommends** 本包，不硬依赖。
因此在内核已内置驱动的系统上（如 Radxa ROCK 4D 的 6.12 内核），
安装 hwcontrol 不会自动拉入本包。

## 版本

- 包版本：1.1.0
- 驱动版本：3.3.1
- 来源：上游 v1.1.0 安装包
