# rknn3-runtime 1.1.0

RKNN3 运行时（Rockchip NPU 3.x），即上游 RKNN3 SDK 的板端 runtime 部分。

## 支持的平台

依据上游 rknn3-toolkit 官方 README 的 *Supported Platforms* 列表：

| 型号 | 说明 |
|---|---|
| RK1820 | AI 协处理器（PCIe/USB 模组） |
| RK1828 | AI 协处理器（PCIe/USB 模组） |
| RK3572 | 本机 NPU（不支持 LLM） |

> **注意**：RK3588/RK3576/RK3566/RK3568/RK3562 系列、RV1103/RV1106、
> RV1103B/RV1106B、RV1126B、RK2118 属于 **RKNN2** 体系，
> 请使用 `rknn2-runtime` 包（对应上游 rknn-toolkit2）。
>
> RK1808/RV1109/RV1126/RK3399Pro 属于更早的 RKNN1 体系，不在本包范围。

## 在 RKNN3 软件栈中的位置

```
  PC 端（x86_64）                       板端（aarch64）
  ┌──────────────────────┐            ┌──────────────────────┐
  │ rknn3-toolkit        │  .rknn     │ rknn3-runtime（本包）│
  │  模型转换 / 量化 /    │ ────────▶  │  librknn3_api.so     │
  │  仿真推理             │            │  librknn3_api_native │
  └──────────────────────┘            │  librknn3_api_rkcp   │
                                      │  rknn3_api.h 等头文件│
                                      │  rknn3-server        │
                                      └──────────────────────┘
```

## 内容

| 文件 | 说明 |
|---|---|
| `/usr/lib/aarch64-linux-gnu/librknn3_api.so` | RKNN3 API 主库（分发层） |
| `/usr/lib/aarch64-linux-gnu/librknn3_api_native.so` | 本机 NPU 后端（RK3572） |
| `/usr/lib/aarch64-linux-gnu/librknn3_api_rkcp.so` | 协处理器后端（RK1820/RK1828） |
| `/usr/lib/aarch64-linux-gnu/gstreamer-1.0/libgstrknn.so` | GStreamer 推理插件 |
| `/usr/lib/aarch64-linux-gnu/libgstrknnutils.so` | GStreamer 插件工具库 |
| `/usr/lib/aarch64-linux-gnu/lib*postprocess.so` | 后处理库（resnet/mobilenet/yolov5s/yolov6s/yolov8s） |
| `/usr/include/rknn3_api.h` | 主 API 头文件 |
| `/usr/include/float16.h` | 半精度浮点头文件 |
| `/usr/bin/rknn3-server` | 推理服务端 |
| `/usr/lib/systemd/system/rknn3-server.service` | 服务单元 |

## 与硬件包的关系

本包**与硬件无关**，不依赖任何具体封装形态（M.2 / SODIMM / NET）。

- EP 设备管理器 `rknn3_transfer_proxy` 由 `rknn3-rk182x-hwcontrol` 提供
- 固件镜像由 `rknn3-rk182x-firmware-{m2,sodimm,sodimm-net}` 之一提供
- LLM 推理服务 `rkllm3-server` 由 `rknn3-runtime-llm` 提供

纯本机 NPU（RK3572）场景只需安装本包。

## 版本

- 包版本：1.1.0
- 来源：rknn3-toolkit `rknn3-runtime`

