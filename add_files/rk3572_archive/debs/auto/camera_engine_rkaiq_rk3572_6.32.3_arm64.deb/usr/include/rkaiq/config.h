/*
 * Copyright (c) 2022 Rockchip Eletronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#ifndef RKAIQ_CONFIG_H
#define RKAIQ_CONFIG_H

/* Auto generated file, do not modify */

#define RKAIQ_HAVE_YNR_V2 0
#if RKAIQ_HAVE_AWB_V32
#define RKAIQ_HAVE_AWB_V32LT 0
#endif
#define RKAIQ_HAVE_AWB_V39 1
#if RKAIQ_HAVE_AWB_V39
#define RKAIQ_HAVE_AWB_V33 1
#endif
#define RKAIQ_HAVE_AWB_V32 0
#define RKAIQ_HAVE_AWB_V21 0
#define RKAIQ_HAVE_AWB_V20 0
#define RKAIQ_HAVE_GIC_V1 0
#define RKAIQ_HAVE_GIC_V2 0
#define RKAIQ_HAVE_ORB_V1 0
#define RKAIQ_HAVE_EIS_V1 0
#define RKAIQ_HAVE_CAC_V03 0
#define RKAIQ_HAVE_CAC_V10 0
#define RKAIQ_HAVE_CAC_V11 0
#if RKAIQ_HAVE_CAC_V11
#define RKAIQ_HAVE_CAC_V12 0
#endif
#define RKAIQ_HAVE_YNR_V1 0
#define RKAIQ_HAVE_YNR_V3 0
#define RKAIQ_HAVE_UVNR_V1 0
#define RKAIQ_HAVE_CNR_V1 0
#define RKAIQ_HAVE_CNR_V2 0
#define RKAIQ_HAVE_SHARP_V1 0
#define RKAIQ_HAVE_SHARP_V3 0
#define RKAIQ_HAVE_SHARP_V4 0
#define RKAIQ_HAVE_MFNR_V1 0
#define RKAIQ_HAVE_BAYERNR_V1 0
#define RKAIQ_HAVE_BAYERNR_V2 0
#define RKAIQ_HAVE_BAYER2DNR_V2 0
#define RKAIQ_HAVE_BAYERTNR_V2 0
#define RKAIQ_HAVE_GAIN_V1 0
#define RKAIQ_HAVE_GAIN_V2 1
#define RKAIQ_HAVE_BLC_V1 0
#define RKAIQ_HAVE_BLC_V32 1
#define RKAIQ_HAVE_ANR_V1 0
#define RKAIQ_HAVE_AMD_V1 0
#define RKAIQ_HAVE_AF_V20 0
#define RKAIQ_HAVE_AF_V30 0
#define RKAIQ_HAVE_AF_V31 0
#define RKAIQ_HAVE_AF_V32_LITE 0
#define RKAIQ_HAVE_AF_V33 1
#define RKAIQ_ONLY_AF_STATS_V20 0
#define RKAIQ_ONLY_AF_STATS_V30 0
#define RKAIQ_ONLY_AF_STATS_V31 0
#define RKAIQ_ONLY_AF_STATS_V32_LITE 0
#define RKAIQ_ONLY_AF_STATS_V33 0
#define RKAIQ_HAVE_3DLUT_V1 0
#define RKAIQ_HAVE_CCM_V1 0
#define RKAIQ_HAVE_CCM_V2 0
#define RKAIQ_HAVE_CCM_V3 1
#define RKAIQ_HAVE_GAMMA_V10 0
#define RKAIQ_HAVE_GAMMA_V11 1
#define RKAIQ_HAVE_MERGE_V10 0
#define RKAIQ_HAVE_MERGE_V11 0
#define RKAIQ_HAVE_MERGE_V12 0
#define RKAIQ_HAVE_DRC_V10 0
#define RKAIQ_HAVE_DRC_V11 0
#define RKAIQ_HAVE_DRC_V12 0
#define RKAIQ_HAVE_DRC_V12_LITE 0
#define RKAIQ_HAVE_DRC_V20 0
#define RKAIQ_HAVE_DEHAZE_V10 0
#define RKAIQ_HAVE_DEHAZE_V11 0
#define RKAIQ_HAVE_DEHAZE_V11_DUO 0
#define RKAIQ_HAVE_DEHAZE_V12 0
#define RKAIQ_HAVE_DEHAZE_V14 0
#define RKAIQ_HAVE_DEGAMMA_V1 0
#define RKAIQ_HAVE_RGBIR_REMOSAIC_V10 0
#define RKAIQ_HAVE_RGBIR_REMOSAIC 0
#define RKAIQ_HAVE_TMO_V1 0
#define RKAIQ_HAVE_WDR_V1 0
#define RKAIQ_HAVE_LDCH_V10 0
#define RKAIQ_HAVE_FEC_V10 0
#define RKAIQ_HAVE_CSM_V1 1
#define RKAIQ_HAVE_CGC_V1 1
#define RKAIQ_HAVE_AE_V1 1
#define RKAIQ_HAVE_AFD_V1 0
#define RKAIQ_HAVE_AFD_V2 1
#define RKAIQ_HAVE_DEBAYER_V1 0
#define RKAIQ_HAVE_DEBAYER_V2 0
#define RKAIQ_HAVE_DEBAYER_V2_LITE 0
#define RKAIQ_HAVE_DEBAYER_V3 1
#define RKAIQ_HAVE_BAYER2DNR_V23 0
#define RKAIQ_HAVE_BAYERTNR_V23 0
#define RKAIQ_HAVE_BAYERTNR_V23_LITE 0
#define RKAIQ_HAVE_YNR_V22 0
#define RKAIQ_HAVE_YNR_V24 0
#define RKAIQ_HAVE_CNR_V30 0
#define RKAIQ_HAVE_CNR_V30_LITE 0
#define RKAIQ_HAVE_SHARP_V33 0
#define RKAIQ_HAVE_SHARP_V33_LITE 0
#define RKAIQ_HAVE_SHARP_V34 0
#define RKAIQ_HAVE_LSC_V1 0
#define RKAIQ_HAVE_LSC_V2 0
#define RKAIQ_HAVE_LSC_V3 1
#define RKAIQ_HAVE_LDCH_V21 0
#define RKAIQ_HAVE_DPCC_V1 0
#define RKAIQ_HAVE_ACP_V10 1
#define RKAIQ_HAVE_AIE_V10 1
#define RKAIQ_HAVE_ASD_V10 0
#define RKAIQ_HAVE_BAYERTNR_V30 0
#define RKAIQ_HAVE_YUVME_V1 0
#define RKAIQ_HAVE_CNR_V31 0
#define RKAIQ_HAVE_LDCH_V22 1
#define RKAIQ_HAVE_LDCV_V22 1
#define RKAIQ_HAVE_BAYERTNR_V51 1
#define RKAIQ_HAVE_GIC_V4 0

#endif /* RKAIQ_CONFIG_H */
