# rknn2-runtime 2.5.0

RKNN2 运行时（Rockchip NPU 2.x），即上游 RKNN-Toolkit2 的板端 runtime 部分。

## 支持的平台

依据上游 RKNN-Toolkit2 官方 README 的 *Support Platform* 列表：

| 系列 | 具体型号 |
|---|---|
| RK3588 系列 | RK3588 / RK3588S |
| RK3576 系列 | RK3576 |
| RK3566/RK3568 系列 | RK3566 / RK3568 |
| RK3562 系列 | RK3562 |
| RV1103/RV1106 | RV1103 / RV1106 |
| RV1103B/RV1106B | RV1103B / RV1106B |
| RV1126B | RV1126B |
| RK2118 | RK2118 |

> 上述列表与 `librknnrt.so` 内嵌的平台字符串完全一致，可用
> `strings -a /usr/lib/aarch64-linux-gnu/librknnrt.so | grep -E '^RK|^RV'` 复核。
>
> **注意**：RK182x 属于 RKNN3（协处理器）体系，由 `rknn3-runtime` 提供，
> 不在本包支持范围内。

## 在 RKNN 软件栈中的位置

```
  PC 端（x86_64）                       板端（aarch64）
  ┌──────────────────────┐            ┌──────────────────────┐
  │ rknn-toolkit2        │  .rknn     │ rknn2-runtime（本包）│
  │  模型转换 / 量化 /    │ ────────▶  │  librknnrt.so        │
  │  仿真推理             │            │  librknnmrt.so       │
  └──────────────────────┘            │  rknn_api.h 等头文件 │
                                      │  rknn_server（可选） │
                                      └──────────────────────┘
```

- **PC 端**：`rknn-toolkit2`（Python 包）负责把 ONNX / PyTorch 等模型转换成 `.rknn`
- **板端**：本包提供 C/C++ 运行时库与头文件，供应用直接链接

## 内容

| 文件 | 说明 |
|---|---|
| `/usr/lib/aarch64-linux-gnu/librknnrt.so` | RKNN2 运行时库（主库） |
| `/usr/lib/aarch64-linux-gnu/librknnmrt.so` | RKNN2 矩阵运算库 |
| `/usr/include/rknn_api.h` | 主 API 头文件 |
| `/usr/include/rknn_custom_op.h` | 自定义算子头文件 |
| `/usr/include/rknn_matmul_api.h` | 矩阵运算 API 头文件 |
| `/usr/bin/rknn_server` | NPU 设备管理器（USB/PCIe） |
| `/usr/lib/systemd/system/rknn2-server.service` | 服务单元 |

## 使用

```bash
# 编译示例（本机 NPU 直接链接 librknnrt.so，无需 rknn_server）
gcc -o demo demo.c -lrknnrt

# 仅在使用 USB/PCIe 外接 NPU 时才需要启用 rknn_server
sudo systemctl enable --now rknn2-server
systemctl status rknn2-server
journalctl -u rknn2-server -f
```

> **注意**：`rknn2-server.service` 安装后**默认不启用**。
> 本机 NPU（如 RK3588/RK3576/RK3562）直接通过 `librknnrt.so` 访问，无需该服务；
> 只有 USB/PCIe 外接 NPU 场景才需要手动启用。

## 与上游脚本的对应关系

上游 `rknpu2/runtime/Linux/rknn_server/aarch64/usr/bin/` 提供两个脚本，
本包**不打包**它们，改用 systemd 原生能力：

| 上游脚本 | 原逻辑 | 本包替代方式 |
|---|---|---|
| `start_rknn.sh` | `while true; do sleep 1; rknn_server; done` | `Restart=always` + `RestartSec=1` |
| `restart_rknn.sh` | `killall start_rknn.sh; killall rknn_server; start_rknn.sh &` | `systemctl restart rknn2-server` |

好处：日志进 journald、状态可查、开机自启、崩溃自动重启。

## 与 rknn3-runtime 的关系

两者**互相独立**，可共存：

- `rknn2-runtime`：RKNN2 模型，用于**本机 NPU**（RK3588/RK3576/RK3566/RK3568/RK3562/RV1103/RV1106/RV1103B/RV1106B/RV1126B/RK2118）
- `rknn3-runtime`：RKNN3 模型，用于 **RK182x 协处理器**

GStreamer 插件 `libgstrknn.so`（在 rknn3-runtime 中）同时支持两代模型格式，
内部做 RKNN2 → RKNN3 格式转换。

## 版本

- 包版本：2.5.0
- 来源：rknn2-toolkit `rknpu2/runtime`
- toolkit commit：`2c723177a94fac65cbc036d722907ddbc91980cf`
