# rknn3-rk182x-hwcontrol 1.1.0

RK182x AI 协处理器的**硬件发现 + 固件上传**工具集。

本包**不依赖** `rknn3-runtime`，只负责把硬件带起来；
推理库由 `rknn3-runtime` 提供，固件镜像由三个固件包之一提供。

## 支持的硬件

| 型号 | 说明 |
|---|---|
| RK1820 | AI 协处理器 |
| RK1828 | AI 协处理器 |

封装形态（M.2 / SODIMM / SODIMM-NET）与通信接口（PCIe / USB / 以太网）
是**正交**的两个维度，本包对三者统一处理。

## 内容

| 文件 | 说明 |
|---|---|
| `/usr/bin/rknn3_transfer_proxy` | EP 设备管理器（操作 `/dev/pcie-rkep`、`/dev/usb-ffs`） |
| `/usr/bin/pcie_upgrade_tool` | PCIe 固件上传工具 |
| `/usr/bin/upgrade_tool` | USB MaskROM 固件上传工具（实体在 `/usr/lib/rknn3-rk182x/upgrade_tool/`） |
| `/usr/bin/rknn_upgrade_tool` | 通用固件上传工具 |
| `/usr/bin/rknn-mdns` | mDNS 设备发现 |
| `/usr/bin/rknn-smi` | 设备状态查询 |
| `/usr/bin/rknn-console` | 设备控制台 |
| `/usr/bin/pcie_speed_test_rc` | PCIe 速率测试 |
| `/usr/lib/rknn3-rk182x/rknn3_startup` | PCIe 驱动加载 + 固件上传编排 |
| `/usr/lib/rknn3-rk182x/rknn3_usb_startup` | USB MaskROM 固件上传（udev 触发） |
| `/usr/lib/udev/rules.d/75-rknn3-coprocessor.rules` | USB 设备识别规则 |
| `/usr/lib/tmpfiles.d/rknn3.conf` | 锁文件创建 |

## 服务架构

| 单元 | 类型 | 作用 |
|---|---|---|
| `rknn3.service` | `Type=simple` | `ExecStartPre=-rknn3_startup` 刷固件（EP 已运行则跳过），然后前台运行 `rknn3_transfer_proxy` |
| `rknn3_usb_startup@.service` | `Type=oneshot` | udev 触发，USB MaskROM 刷机，`flock` 串行化，180s 超时 |
| `rknn3-mdns.service` | `Type=simple` | mDNS 设备发现（需网络） |

> `rknn3_transfer_proxy` **不会 daemonize**，它一直前台运行
> （DeviceManager 主循环 + 为每个 EP 设备 fork 子 proxy），因此用 `Type=simple`。
> 若误用 `Type=forking`，systemd 会一直等父进程退出而卡在 `activating`，
> 超时被杀后反复重启，旧实例残留还会导致 `Address already in use`。
>
> 服务配置了 `KillMode=control-group`，停止时会终止整个进程组（含子 proxy）。

## 固件从哪来

本包**不含固件**。请安装以下三个包之一（互斥）：

- `rknn3-rk182x-firmware-m2`
- `rknn3-rk182x-firmware-sodimm`
- `rknn3-rk182x-firmware-sodimm-net`

固件统一安装为 `/usr/lib/firmware/rknn3_rk1820.img`。

> **为什么不能自动识别该刷哪份固件**：
> 三种封装进入 MaskROM 后 USB ID 均为 `2207:180b`，PCI Subsystem ID 为 `0x0000`，
> 且 `rknn-smi` 在固件刷入前无法返回板型（返回 `Product Name: NA`）。
> 因此只能由用户选择安装哪个固件包 —— **装哪个包，就刷哪份固件**。

## 内核驱动

`pcie-rkep` 驱动若已编入内核（如 Radxa ROCK 4D 的 6.12 内核），
则**无需**安装 `pcie-rkep-dkms`。本包只 `Recommends` 它，不硬依赖。

检查方法：

```bash
ls /sys/bus/pci/drivers/pcie-rkep
modinfo pcie-rkep
```

任一成功即说明驱动已就绪。

## 版本

- 包版本：1.1.0
- 来源：上游 v1.1.0 安装包 + v1.1.1a1 的 service/udev 架构
